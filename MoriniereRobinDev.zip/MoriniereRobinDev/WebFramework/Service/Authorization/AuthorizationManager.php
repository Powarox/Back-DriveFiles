<?php

namespace MoriniereRobinDev\WebFramework\Service\Authentorization;

class AuthorizationManager
{
    public function __construct()
    {
    }

    public function chekPermission()
    {
    }
}
